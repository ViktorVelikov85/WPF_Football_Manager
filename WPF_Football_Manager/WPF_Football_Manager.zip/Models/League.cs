﻿using System;

namespace WPF_WPF_Football_Manager.Models
{
    public class League
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Season { get; set; }

    }
}